package com.example.example_kol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleKolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleKolApplication.class, args);

	}

}
